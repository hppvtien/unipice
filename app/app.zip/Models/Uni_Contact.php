<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Uni_Contact extends Model
{
    use HasFactory;

    protected $table = 'uni_contact';
    protected $guarded = [''];
}
