<?php

return [
    'name' => 'Admin',
];
