<!-- Footer opened -->
<div class="main-footer ht-40">
    <div class="container-fluid pd-t-0-f ht-100p">
        <span>Copyright © 2020 <a href="https://adsmo.vn">Admin</a>. Designed by <a href="https://adsmo.vn">Adsmo</a> </span>
    </div>
</div>
<!-- Footer closed -->				<!-- Back-to-top -->
<a href="empty#top" id="back-to-top"><i class="las la-angle-double-up"></i></a>
