import AutoloadJs from '../../components/_inc_autoload'
$(function (){
    AutoloadJs.init()
})