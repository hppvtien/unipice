 <?php $__env->startSection('contents'); ?>

<main role="main">
    <a id="main-content" tabindex="-1"></a>
    <div class="layout-content">
        <div class="region region-content">
            <div data-drupal-messages-fallback class="hidden"></div>
            <div id="block-frontiercoop-market-content">
                <article>
                    <div>
                        <div class="layout layout--onecol">
                            <div class="layout__region layout__region--content">
                                <div data-block-plugin-id="system_breadcrumb_block">
                                    <nav class="m-breadcrumb" aria-label="Breadcrumb">
                                        <h2 class="visually-hidden">Breadcrumb</h2>
                                        <ol class="m-breadcrumb__list">
                                            <li class="m-breadcrumb__item">
                                                <a class="a-anchor" href="/">Home</a>
                                            </li>
                                            <li class="m-breadcrumb__item">
                                                <a class="a-anchor" href="<?php echo e(getSlugProduct($product->slug)); ?>"> <?php echo e($product->name); ?> </a>
                                            </li>
                                        </ol>
                                    </nav>

                                </div>
                            </div>
                        </div>
                       
                        <div class="layout layout--onecol">
                            <div class="layout__region layout__region--content">
                                <div>
                                    <div class="c-product-overview">
                                        <div class="c-product-overview__content-wrapper">
                                            <div class="m-product-gallery glide">
                                                <div class="m-product-gallery__track glide__track" data-glide-el="track">
                                                    <ul class="m-product-gallery__slides glide__slides">
                                                        <?php $__empty_1 = true; $__currentLoopData = json_decode($product->album); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <li class="m-product-gallery__slide glide__slide">
                                                            <div class="m-product-gallery__img-wrapper">
                                                                <img class="lazyload m-product-gallery__img" data-src="<?php echo e(pare_url_file_product($item)); ?>" alt="<?php echo e($product->name); ?>" data-zoom="<?php echo e(pare_url_file_product($item)); ?>">
                                                        </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <?php endif; ?>

                                                    </ul>
                                                    </div>
                                                    <div class="a-carousel-indicator glide__arrows m-product-gallery__controls" data-glide-el="controls">
                                                        <button class="a-carousel-indicator__arrow a-carousel-indicator__arrow--left" type="button" aria-label="Prev" data-glide-dir="<">
                                                        <span class="icon-arrow-left"></span>
                                                    </button>

                                                        <div class="a-carousel-indicator__bullets glide__bullets" data-glide-el="controls[nav]">
                                                            <button class="a-carousel-indicator__bullet " type="button" aria-label="Go to slide 0" data-glide-dir="=0" data-slide-number="0">
                                                        </button>
                                                        </div>

                                                        <button class="a-carousel-indicator__arrow a-carousel-indicator__arrow--right" type="button" aria-label="Next" data-glide-dir=">">
                                                        <span class="icon-arrow-right"></span>
                                                    </button>
                                                    </div>
                                                </div>
                                                 
                                                <div class="c-product-overview__info">
                                                    <div class="c-product-overview__content">
                                                        <div class="m-product-overview">
                                                            <div class="m-product-overview__name-wrapper">

                                                                <div class="m-combined-product-name">
                                                                    <h1 class="m-combined-product-name__h1">
                                                                        <span class="a-product-name">
                                                                        <?php echo e($product->name); ?>

                                                                    </span>
                                                                    </h1>
                                                                </div>
                                                                <!-- FC-2249:: Remove markup that should only be available to authenticated users -->
                                                            </div>
                                                            <div class="m-product-overview__unit-and-sku">
                                                                <span class="m-product-overview__sku">Mã sản phẩm: <?php echo e($product->id); ?></span>
                                                            </div>
                                                            <!-- /TODO :: ADD RATING -->
                                                            <div role="article" class="m-product-overview__price-wrapper">
                                                                <div class="m-price-lockup">
                                                                    <!--<span class="m-price-lockup__price">-->
                                                                    <!--<span class="a-price">-->
                                                                    <!--    Giá: <?php echo e($product->price == '' ? 'liên hệ': formatVnd($product->price)); ?>-->
                                                                    <!--</span>-->
                                                                    <span class="m-price-lockup__price">
                                                                        <?php if (checkUid(get_data_user('web')) != null) { ?>    
                                                                            <span class="a-price">
                                                                                Giá: <?php echo e($product->price_sale_store == null ? 'liên hệ': formatVnd($product->qty_in_box * $product->price_sale_store)); ?>

                                                                            </span>
                                                                        <?php } else { ?>
                                                                            <span class="a-price">
                                                                                Giá: <?php echo e($product->price == null ? 'liên hệ': formatVnd($product->price)); ?>

                                                                            </span>
                                                                        <?php } ?>
                                                                    </span>
                                                                    <!--</span>-->
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="m-product-overview__unit-and-sku">
                                                                <span class="a-folio">
                                                                <?php echo e($trade_name); ?>

                                                            </span>
                                                            </div>
                                                            <div role="article" class="m-product-overview__price-wrapper">
                                                                <div class="m-price-lockup">
                                                                    <span class="m-price-lockup__price">
                                                                    <span class="a-qty">
                                                                        Số lượng: <?php echo e($product->qty == '' ? 'Hiện tại hết hàng': $product->qty); ?>

                                                                    </span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div role="article" class="m-product-overview__price-wrapper">
                                                                <div class="m-price-lockup">

                                                                    <span class="m-price-lockup__price">
                                                                    <span class="a-product-name a-title-des">
                                                                        Mô tả về sản phẩm: </br>
                                                                    </span>
                                                                    <span class="a-folio">
                                                                        <?php echo e($product->desscription); ?>

                                                                    </span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <form class="m-product-overview__add-to-cart">
                                                            </form>
                                                        </div>
                                                        
                                                        <div id="row" style="margin-bottom: 30px;">
                                                        <div class="m-product-card__content-wrapper row">
                                                            <?php if (checkUid(get_data_user('web')) != null) { ?>
                                                                <div class="m-product-card__add-to-cart col-md-6 col-lg-6 col-12" style="opacity: 1;display:block;position: unset;pointer-events: auto;">
                                                                    <button style="padding: 16px 10px;display:block;width:100%;margin-bottom:10px" class="a-btn a-btn--primary m-product-card__add-to-cart-btn js-add-cart" data-min-box="<?php echo e($product->min_box); ?>" data-qtyinbox="<?php echo e($product->qty_in_box); ?>" data-url="<?php echo e(route('get_user.cart.add',['id' => $product->id,'type' => 'single'])); ?>" data-uid="<?php echo e(get_data_user('web')); ?>" type="button">Thêm giỏ hàng</button>
                                                                  
                                                                </div>
                                                            <?php } else { ?>
                                                                <div class="m-product-card__add-to-cart col-md-6 col-lg-6 col-12" style="opacity: 1;display:block;position: unset;pointer-events: auto;">
                                                                    <button style="padding: 16px 10px;display:block;width:100%;margin-bottom:10px" class="a-btn a-btn--primary m-product-card__add-to-cart-btn js-add-cart" data-url="<?php echo e(route('get_user.cart.add',['id' => $product->id,'type' => 'single'])); ?>" data-uid="<?php echo e(get_data_user('web')); ?>" data-id="<?php echo e($product->id); ?>" type="button">
                                                                        <?php if(get_data_user('web')) { echo "Thêm giỏ hàng";} else { echo "Vui lòng đăng nhập để mua hàng";}?>
                                                                        </button>
                                                                </div>
                                                            <?php } ?>
                                                            <div class="m-product-card__add-to-cart col-md-6 col-lg-6 col-12" style="opacity: 1;display:block;position: unset;pointer-events: auto;">
                                                                <button style="display:block;width:100%;margin-bottom:10px" class="a-btn a-btn--primary m-product-card__add-to-cart-btn " onclick="check_my_favorites_add(this);" data-url="<?php echo e(route('get_user.cart.add',['id' => $product->id,'type' => 'single'])); ?>" data-uid="<?php echo e(get_data_user('web')); ?>" data-id="<?php echo e($product->id); ?>" type="button">Yêu thích</button>
                                                            
                                                            </div>
                                                        </div>
                                                        <script>
                                                            function check_my_favorites_add(my_id) {
                                                                var title = $(my_id).attr('data-id');
                                                                $.get("<?php echo e(route('get_user.myfavorites_add')); ?>", {
                                                                        id: title
                                                                    })
                                                                    .done(function(data) {
                                                                        alert(data);
                                                                        location.reload();
                                                                    });
                                                            }
                                                        </script>
                                                    </div>
                                                        <!-- Review :: this should be removed -->
                                                        <div id="share">

                                                            <!-- facebook -->
                                                            <a class="facebook" href="https://www.facebook.com/share.php?u=url&title=title" target="blank"><i class="fa fa-facebook"></i></a>

                                                            <!-- twitter -->
                                                            <a class="twitter" href="https://twitter.com/intent/tweet?status=title+url" target="blank"><i class="fa fa-twitter"></i></a>

                                                            <!-- google plus -->
                                                            <a class="googleplus" href="https://plus.google.com/share?url=url" target="blank"><i class="fa fa-google-plus"></i></a>

                                                            <!-- linkedin -->
                                                            <a class="linkedin" href="https://www.linkedin.com/shareArticle?mini=true&url=url&title=title&source=source" target="blank"><i class="fa fa-linkedin"></i></a>

                                                            <!-- pinterest -->
                                                            <a class="pinterest" href="https://pinterest.com/pin/create/bookmarklet/?media=media&url=url&is_video=false&description=title" target="blank"><i class="fa fa-pinterest-p"></i></a>

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="layout layout--onecol">
                                <div class="col-md-12 container">

                                    <button id="defaultOpen" class="tablink " onclick="openPage('Home', this, '#e88012')">Chi Tiết</button>
                                    <button class="tablink" onclick="openPage('News', this, '#e88012')">Đánh Giá</button>

                                    <div id="Home" class="tabcontent">
                                        <?php echo $product->content; ?>

                                    </div>

                                    <div id="News" class="tabcontent">
                                        <div class="">
                                            <div>
                                                <textarea id="noi_dung_commnet" class="form-control" rows="2" placeholder="Hãy để lại bình luận của bạn...!"></textarea>
                                                <div class="mar-top clearfix">
                                                    <button token="<?php echo e(csrf_token()); ?>" onclick="add_comment_user(this);" product_id="<?php echo e($product->id); ?>" user_id="<?php echo $user_id; ?>" class="btn btn-sm btn-primary pull-right" type="submit"><i class="fa fa-pencil fa-fw"></i> Bình Luận</button>
                                                </div>
                                            </div>
                                            <div>

                                                <div>
                                                    <!-- Newsfeed Content -->
                                                    <!--===================================================-->
                                                    <?php $__currentLoopData = $noi_dung_comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="media-block">
                                                        <a class="media-left" href="#"><img class="img-circle img-sm" alt="Profile Picture" src="https://bootdey.com/img/Content/avatar/avatar1.png"></a>
                                                        <div class="media-body">
                                                            <div class="mar-btm">
                                                                <a href="#" class="btn-link text-semibold media-heading box-inline"><?php echo e(get_user_comment_product($item->user_id)); ?></a>

                                                            </div>
                                                            <p class="margin-left1"><?php echo e($item->noi_dung_comment); ?></p>

                                                            <hr>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                    <!--===================================================-->
                                                    <!-- End Newsfeed Content -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="non-visible layout layout--onecol">
                            <div class="c-categories-slider layout layout--onecol">

                                <div class="layout__region layout__region--heading">
                                    <div class="c-categories-slider__heading-wrapper layout-builder__add-block">


                                        <div class="m-heading">
                                            <h2 class="m-heading__headline">
                                                Sản phẩm Yêu Thích
                                            </h2>
                                        </div>


                                    </div>
                                </div>
                                <div class="layout__region layout__region--content">
                                    <div class="c-categories-slider__container js-swiper-container">
                                        <ul class="c-categories-slider__slider js-swiper-wrapper">
                                            <?php $__empty_1 = true; $__currentLoopData = $product_fav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <li class="c-categories-slider__item js-swiper-slide">
                                                <a class="m-category-card m-category-card--bordered" href="<?php echo e($item->slug); ?>">
                                                    <div class="m-category-card__image-wrapper">
                                                        <picture>
                                                            <source media="(min-width: 768px)" data-srcset="<?php echo e(pare_url_file($item->thumbnail)); ?>">
                                                            <img class="lazyload" data-src="<?php echo e(pare_url_file($item->thumbnail)); ?>" alt="<?php echo e(pare_url_file($item->thumbnail)); ?>">
                                                        </picture>
                                                        <div class="m-category-card__caption">
                                                            <span class="m-category-card__caption-text"><?php echo e($item->name); ?></span>
                                                        </div>
                                                        <div class="m-category-card__caption">
                                                            <p><?php echo e(desscription_cut($item->desscription,60)); ?></p>
                                                        </div>
                                                    </div>
                                                </a>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <?php endif; ?>


                                        </ul>
                                        <div class="a-carousel-indicator a-carousel-indicator--no-bullets a-carousel-indicator--arrows c-categories-slider__arrows">
                                            <button class="a-carousel-indicator__arrow a-carousel-indicator__arrow--left js-swiper-button-prev" type="button" aria-label="Prev">
                                            <span class="icon-arrow-left"></span>
                                        </button>
                                            <button class="a-carousel-indicator__arrow a-carousel-indicator__arrow--right js-swiper-button-next" type="button" aria-label="Next">
                                            <span class="icon-arrow-right"></span>
                                        </button>
                                        </div>
                                        <div class="c-products-slider__scrollbar">
                                            <div class="a-slider-scrollbar">
                                                <div class="a-slider-scrollbar__inner js-swiper-scrollbar">

                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="layout layout--onecol">
                            <div class="layout__region layout__region--content">
                                <div data-block-plugin-id="inline_block:media_block" data-inline-block-uuid="ee168006-3fe9-4f1c-bbc5-ba42ddc90f9a" class="c-media-block c-media-block--template-">
                                    <div class="c-media-block__image-wrapper">
                                        <picture>
                                            <source media="(min-width: 768px)" data-srcset="<?php echo e(pare_url_file($slides_home_four1->s_banner)); ?>" srcset="<?php echo e(pare_url_file($slides_home_four1->s_banner)); ?>">
                                            <img class=" lazyloaded" data-src="<?php echo e(pare_url_file($slides_home_four1->s_banner)); ?>" alt=" " src="<?php echo e(pare_url_file($slides_home_four1->s_banner)); ?>">
                                        </picture>
                                    </div>

                                    <div class="c-media-block__content">
                                        <div class="c-media-block__headline">Baking soda baths are a great way to detox. Check out the benefits of baking soda baths and how to do one at home!</div>


                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="non-visible layout layout--onecol">
                            <div class="c-categories-slider layout layout--onecol">

                                <div class="layout__region layout__region--heading">
                                    <div class="c-categories-slider__heading-wrapper layout-builder__add-block">


                                        <div class="m-heading">
                                            <h2 class="m-heading__headline">
                                                Sản phẩm liên quan
                                            </h2>
                                        </div>


                                    </div>
                                </div>
                                <div class="layout__region layout__region--content">
                                    <div class="c-categories-slider__container js-swiper-container">
                                        <ul class="c-categories-slider__slider js-swiper-wrapper">
                                            <?php $__empty_1 = true; $__currentLoopData = $product_related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <li class="c-categories-slider__item js-swiper-slide">
                                                <a class="m-category-card m-category-card--bordered" href="<?php echo e($item->slug); ?>">
                                                    <div class="m-category-card__image-wrapper">
                                                        <picture>
                                                            <source media="(min-width: 768px)" data-srcset="<?php echo e(pare_url_file($item->thumbnail)); ?>">
                                                            <img class="lazyload" data-src="<?php echo e(pare_url_file($item->thumbnail)); ?>" alt="<?php echo e(pare_url_file($item->thumbnail)); ?>">
                                                        </picture>
                                                        <div class="m-category-card__caption">
                                                            <span class="m-category-card__caption-text"><?php echo e($item->name); ?></span>
                                                        </div>
                                                        <div class="m-category-card__caption">
                                                            <p><?php echo e(desscription_cut($item->desscription,60)); ?></p>
                                                        </div>
                                                    </div>
                                                </a>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <?php endif; ?>


                                        </ul>
                                        <div class="a-carousel-indicator a-carousel-indicator--no-bullets a-carousel-indicator--arrows c-categories-slider__arrows">
                                            <button class="a-carousel-indicator__arrow a-carousel-indicator__arrow--left js-swiper-button-prev" type="button" aria-label="Prev">
                                            <span class="icon-arrow-left"></span>
                                        </button>
                                            <button class="a-carousel-indicator__arrow a-carousel-indicator__arrow--right js-swiper-button-next" type="button" aria-label="Next">
                                            <span class="icon-arrow-right"></span>
                                        </button>
                                        </div>
                                        <div class="c-products-slider__scrollbar">
                                            <div class="a-slider-scrollbar">
                                                <div class="a-slider-scrollbar__inner js-swiper-scrollbar">

                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="layout layout--onecol">
                        <div class="layout__region layout__region--content">
                            <div class="views-element-container" data-block-plugin-id="views_block:product_detail_page_shop_the_recipe_carousel-block_shop_the_recipe_card">
                                <div class="views-element-container">
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
            </article>
        </div>
    </div>
    </div>

    <script>
        function openPage(pageName, elmnt, color) {
            // Hide all elements with class="tabcontent" by default */
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                
                tabcontent[i].style.display = "none";
            }

            // Remove the background color of all tablinks/buttons
            tablinks = document.getElementsByClassName("tablink");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].style.backgroundColor = "";
               

            }

            // Show the specific tab content
            document.getElementById(pageName).style.display = "block";

            // Add the specific color to the button used to open the tab content
            elmnt.style.backgroundColor = color;
            

        }

        // Get the element with id="defaultOpen" and click on it
        document.getElementById("defaultOpen").click();

        function add_comment_user(id) {
            var user_id = $(id).attr('user_id');
            var product_id = $(id).attr('product_id');
            var token = $(id).attr('token');
            var noi_dung_commnet = $('#noi_dung_commnet').val();

            $.post("<?php echo e(route('get.product_comment',['slug'=>$slug])); ?>", {
                    token: token,
                    user_id: user_id,
                    product_id: product_id,
                    noi_dung_commnet: noi_dung_commnet
                })
                .done(function(data) {
                    alert(data);
                    location.reload();
                });
        }
    </script>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layouts.app_master_frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/unispice/eshop.unispice.net/resources/views/pages/product/index.blade.php ENDPATH**/ ?>