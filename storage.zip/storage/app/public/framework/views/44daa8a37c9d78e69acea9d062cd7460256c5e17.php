
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- breadcrumb -->
    <div class="breadcrumb-header justify-content-between">
        <div class="my-auto">
            <div class="d-flex">
                <h4 class="content-title mb-0 my-auto">User</h4>
                <span class="text-muted mt-1 tx-13 ml-2 mb-0">/ index</span>
            </div>
        </div>
    </div>
    <!-- breadcrumb -->
    <!-- row -->
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table mg-b-0 text-md-nowrap">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Tên cửa hàng</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($item->id); ?></th>
                                    <td><?php echo e($item->name); ?></td>
                                    <?php if(get_id_store($item->id)): ?>
                                    <td><a href=" <?php echo e(route('get_admin.uni_store.edit', get_id_store($item->id))); ?>"><?php echo e(get_data_store($item->id)); ?></a></td>
                                    <?php else: ?>
                                    <td>Đại lý chưa cập nhật thông tin</td>
                                    <?php endif; ?>
                                    <td><?php echo e($item->email); ?></td>
                                    <td><?php echo e($item->phone); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('get_admin.user.edit', $item->id)); ?>" class="btn btn-xs btn-info"><i class="la la-edit"></i></a>
                                        <a href="<?php echo e(route('get_admin.user.movetrash', $item->id)); ?>" class="btn btn-xs btn-danger"><i class="la la-trash"></i></a>
                                    </td>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/unispice/eshop.unispice.net/Modules/Admin/Resources/views/pages/user/store_index.blade.php ENDPATH**/ ?>