<!doctype html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="ROBOTS" content="NOINDEX, NOFOLLOW"> <?php echo SEO::generate(); ?>

    <link rel="icon" href="<?php echo e(asset('img/brand/favicon.png')); ?>" type="image/x-icon" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" /> 
    <?php if(session('toastr')): ?>
    <script>
        var TYPE_MESSAGES = "<?php echo e(session('toastr.type')); ?>"
        var MESSAGE = "<?php echo e(session('toastr.message')); ?>"
    </script>
    <?php endif; ?>
    <link href="<?php echo e(asset('css/css_js/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/frontends.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/css_js/font-awesome.css')); ?>" /> 

    <link rel="stylesheet" href="<?php echo e(asset('css/ducanh.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/css_js/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/ducanh2.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/css_js/css_header_menu/style.css')); ?>">
    <link href="<?php echo e(asset('css/css_js/custom.css')); ?>" rel="stylesheet">


</head>
<div class="zeynep">
<div class="col-md-12 col-xs-12 border_menu_mobile">
        <div class="row menu_can_giua">
            <span class="gach_flag"><img src="https://www.countryflags.io/vn/flat/32.png" alt=""></span>
            <span class="gach_flag"><img src="https://www.countryflags.io/us/flat/32.png" alt=""></span>
        </div>
        <div class="col-lg-12 kich_co">
            <span class="icon-account font_icon_new"> <b>Tài Khoản</b> </span>
            <span class="font_icon_new"> <b>|</b> </span>
            <span class="icon-cart font_icon_new"> <b>Giỏ Hàng</b> </span>
        </div>
        <div class="col-lg-12 kich_co">
            <a href="tel:<?php echo e($configuration->hotline); ?>"><span id="" class="phone-number"><i class="fa fa-phone"></i>  <?php echo e(formatPhoneNumber($configuration->hotline)); ?></span></a>
        </div>
    </div>
    <ul>
        <?php $__empty_1 = true; $__currentLoopData = $category_mn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <li>
            <a href="/<?php echo e(getSlugCategory($item->slug)); ?>"><img style="float: left;padding: 5px;" width="45px" src="<?php echo e(pare_url_file_product($item->icon_thumb)); ?>" alt=""><span> <?php echo e($item->name); ?></span></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <?php endif; ?>
    </ul>
</div>



<div class="zeynep-overlay"></div>

<body>

    <div class="dialog-off-canvas-main-canvas" data-off-canvas-main-canvas>
        <div class="layout-container">
            <?php echo $__env->make('user::pages.component._inc_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
            <?php echo $__env->yieldContent('content'); ?> 
            <?php echo $__env->make('user::pages.component._inc_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>


    <script src="<?php echo e(asset('fontend_js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('css/css_js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('css/css_js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('css/css_js/jquery.zeynep.min.js')); ?>"></script>
    <script src="<?php echo e(asset('fontend_js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('js/frontends.js')); ?>"></script>
    <script src="<?php echo e(asset('fontend_js/unijs.js')); ?>"></script>
    <script>
        jQuery(document).ready(function() {

            var btn = $('.back-to-top');

            $(window).scroll(function() {
                if ($(window).scrollTop() > 500) {
                    btn.addClass('show');
                } else {
                    btn.removeClass('show');
                }
            });

            btn.on('click', function(e) {
                e.preventDefault();
                $('html, body').animate({
                    scrollTop: 0
                }, '1500');
            });

        });
    </script>
    <script>
        $(function() {
            // init zeynepjs
            var zeynep = $('.zeynep').zeynep({
                onClosed: function() {
                    // enable main wrapper element clicks on any its children element
                    $("body main").attr("style", "");

                    console.log('the side menu is closed.');
                },
                onOpened: function() {
                    // disable main wrapper element clicks on any its children element
                    $("body main").attr("style", "pointer-events: none;");

                    console.log('the side menu is opened.');
                }
            });

            // handle zeynep overlay click
            $(".zeynep-overlay").click(function() {
                zeynep.close();
            });

            // open side menu if hamburger menu is clicked
            $("nav .navbar-toggler").click(function() {
                if ($("html").hasClass("zeynep-opened")) {
                    zeynep.close();
                } else {
                    zeynep.open();
                }
            });
        });
    </script>

</body>

</html><?php /**PATH /home/unispice/eshop.unispice.net/Modules/User/Resources/views/pages/layout/app_master_user.blade.php ENDPATH**/ ?>