<?php $__empty_1 = true; $__currentLoopData = $uni_store; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="m-heading get-map-google" data-lat="<?php echo e($item->store_lat); ?>" data_lng="<?php echo e($item->store_lng); ?>">
    <div class="m-heading__cta">
        <h2 class="m-heading__headline heading_namestore"><?php echo e($item->store_name); ?></h2>
        <p class="m-media-block-aligned__description">Địa chỉ: <?php echo e($item->store_address); ?></p>
        <p class="m-media-block-aligned__description">Số điện thoại: <?php echo e($item->store_phone); ?></p>
        <p class="go-map">Xem bản đồ</p>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    
<?php endif; ?><?php /**PATH /home/unispice/eshop.unispice.net/resources/views/pages/find/list_store.blade.php ENDPATH**/ ?>