<?php $__empty_1 = true; $__currentLoopData = $blog_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                     
    <div class="c-story-block <?php echo e($key % 2 != 0 ? 'c-story-block--flipped':''); ?>">
        <div class="c-story-block__content-wrapper">
            <div class="c-story-block__content">
              <h2 class="c-story-block__headline"><?php echo e($item->name); ?></h2>
              <p class="c-story-block__description"><?php echo e($item->desscription); ?></p>
              <div class="c-story-block__cta">
                <a class="a-btn a-btn--secondary" href="<?php echo e($item->slug); ?>" title="<?php echo e($item->name); ?>">Read More</a>
              </div>
            </div>
        </div>

        <div class="c-story-block__image-wrapper">
            <picture>
              <source media="(min-width: 768px)" data-srcset="<?php echo e(pare_url_file($item->thumbnail)); ?>" srcset="<?php echo e(pare_url_file($item->thumbnail)); ?>">
              <img class=" lazyloaded" data-src="<?php echo e(pare_url_file($item->thumbnail)); ?>" alt="<?php echo e($item->name); ?>" src="<?php echo e(pare_url_file($item->thumbnail)); ?>">
            </picture>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    
<?php endif; ?><?php /**PATH /home/unispice/eshop.unispice.net/resources/views/pages/blog/_item_post.blade.php ENDPATH**/ ?>