
<?php $__env->startSection('content'); ?>
<main id="maincontent" class="">

    <div class="columns">
         <?php echo $__env->make('user::pages.component._inc_menu_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="column main padding_css">

            <div>
                <div class="c-filter-bar class_left">

                    <div class="c-filter-bar__sorting">
                        <div class="m-sort-by">
                            <select onchange="get_data1();" class="m-sort-by__select frontier-custom-sort" id="sort_by" name="sort_by" aria-label="Sort By">
                                <option value="0" selected="">Chọn Danh Mục Sản Phẩm</option>
                                <?php $__currentLoopData = $category_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($l->id); ?>"><?php echo e($l->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="m-sort-by__arrow"></span>
                        </div>
                        <div class="m-sort-by">
                            <select onchange="get_data1();" class="m-sort-by__select frontier-custom-sort" id="order_by" name="order_by" aria-label="Order By">
                                <option value="0" selected="">Chọn Sắp Xếp</option>
                                <option value="desc" selected="">Tăng</option>
                                <option value="asc">Giảm</option>
                            </select>
                            <span class="m-sort-by__arrow"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="t-plp__grid js-plp-grid show-product" id="show-product">
                
                <?php $__currentLoopData = $product_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="loadmore1 t-plp__product margin_top_list" data-animate-grid-id="0.7226111054869209" style="transform-origin: 0px 0px;">
                    <div class="views-field views-field-search-api-rendered-item" style="transform-origin: 0px 0px;">
                        <span class="field-content">
                            <div data-product-name="<?php echo e($value->name); ?>" data-product-sku="<?php echo e($value->id); ?>" data-product-brand="frontiercoop_market" data-product-category="<?php echo e(get_category_id($value->id)); ?>" class="m-product-card">
                                <div class="m-product-card__content-wrapper">
                                    <a class="m-product-card__img-wrapper" href="san-pham-10" title="<?php echo e($value->name); ?>">
                                        <img class="m-product-card__img ls-is-cached lazyloaded" data-src="<?php echo e(pare_url_file($value->thumbnail)); ?>" alt="<?php echo e($value->name); ?>" src="<?php echo e(pare_url_file($value->thumbnail)); ?>">
                                    </a>
                                    <form class="m-product-card__add-to-cart">
                                        <button class="a-btn a-btn--primary m-product-card__add-to-cart-btn js-add-cart" type="button">Thêm Vào Giỏ</button>
                                        <button class="a-btn a-btn--primary m-product-card__add-to-cart-icon" type="&quot;submit&quot;">
                                        <span class="icon-add-to-cart"></span>
                                        </button>
                                    </form>
                                </div>
                                <div class="m-product-card__info">
                                    <div class="m-combined-product-name">
                                        <a class="m-combined-product-name__link" href="san-pham-10">
                                            <span class="a-folio"><?php echo e($value->name); ?></span>
                                            <span class="a-product-name"><?php echo e(desscription_cut($value->desscription, 55)); ?></span>
                                        </a>
                                    </div>
                                    <div class="m-product-card__sku">SKU: <?php echo e($value->id); ?> <span my-id="<?php echo e($value->id); ?>" onclick="check_my_favorites_add(this);" class="icon-favorite  a-icon-text-btn__icon <?php foreach ($my_favorites as  $l) {
                                        if($value->id == $l){
                                            echo 'red';
                                        }else {
                                            echo  '';
                                        }
                                    } ?>" aria-hidden="true"></span></div>
                                    <div class="m-price-lockup m-product-card__price">
                                        <span class="m-price-lockup__price" style="display: none">
                                            <span class="a-price"></span>
                                        </span>
                                    </div>
                                </div>
                                <div class="m-product-card__cta"></div>
                            </div>
                        </span>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div>
                <a href="#" id="loadMore">Xem Thêm</a>
            </div>
   

</main>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('user::pages.layout.app_master_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/unispice/eshop.unispice.net/Modules/User/Resources/views/pages/dashboard/product_list.blade.php ENDPATH**/ ?>